DROP TABLE IF EXISTS `#__lms4labs_config`;

DROP TABLE IF EXISTS `#__lms4labs`;
