DROP TABLE IF EXISTS `#__lms4labs_config`;
