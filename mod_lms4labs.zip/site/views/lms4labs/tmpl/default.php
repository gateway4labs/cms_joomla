<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
?>
<h1>LMS4Lab</h1>

<?php
    echo "<form method=\"POST\" action=\"" . $this->url . "\"><input type=\"submit\" value=\"Run\"></form>";
?>
